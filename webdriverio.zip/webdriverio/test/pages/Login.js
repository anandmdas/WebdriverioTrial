import * as LoginPageObject from "../pageobjects/LoginPageObject.js";
import * as expectChai from "chai"
class Login
{
     async loginErrorValidation(username,password)
    {
        await browser.url("https://www.rahulshettyacademy.com/loginpagePractise/");
        (await LoginPageObject.btnSignin).waitForClickable(
            {
                timeout:20000,
                timeoutMsg:LoginPageObject.btnSignin+" is not clickable"
            }
        );
        await (await LoginPageObject.iptUserName).setValue(username);
        await (await LoginPageObject.iptPassword).setValue(password);
        await (await LoginPageObject.btnSignin).click();
        await (await LoginPageObject.lblAlert).waitForDisplayed({
            timeout:10000,
            timeoutMsg:LoginPageObject.lblAlert+" is not displayed"
        });
        expectChai.expect((await LoginPageObject.lblAlert).getText()).to.equal('Incorrect username/password')
    }
}
export default new Login()