describe('Rahul shetty E comerese Application',async()=>
{
    it('Login Failure Scenarion',async()=>
    {
        await browser.url("https://www.rahulshettyacademy.com/loginpagePractise/");
        console.log(await browser.getTitle());
        await expect(browser).toHaveTitleContaining("Rahul Shetty");
       
        await $("username").setValue("anand");
        await browser.pause(3000);
    })

})