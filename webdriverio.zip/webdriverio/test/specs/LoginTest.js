import * as Login from "../pages/Login.js";
describe("Login Page Scenarios", async()=>
{
    it("Login Error Scenario", async()=>
    {
        Login.loginErrorValidation('test','test')
        
    })
}
)