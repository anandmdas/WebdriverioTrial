class LoginPageObject
{
    get iptUserName()
    {
       return $("//*[@id='username']");
    }
    get iptPassword()
    {
        return $("#password");
    }
    get btnSignin()
    {
        return $("#signInBtn");
    }
    get lblAlert()
    {
        return $("//*[contains(@class,'alert alert-danger')]")
    }
 }
export default new LoginPageObject() 